/* 
 * Ravepay Extension for CiviCRM - Circle Interactive 2012-2014
 * Author: andyw@circle
 *
 * Distributed under the GNU General Public License, version 2
 * https://www.gnu.org/licenses/gpl-2.0.html 
 */
